#!/usr/bin/env python3
"""Real canonical candidate runner. Strictly records blocked gates, never promotes."""
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time
sys.path.insert(0, '/home/jeremy/justrust/bench')
import hybrid_suite_gate as gate

ROOT = Path('/home/jeremy/.jcode/scratch/hybrid-gate-20261115-1337')
MANIFEST = ROOT / 'gate-v6-nativev5-fixturenotex'
BASELINE_UNIT = 'justrust-hybrid-off-v5-fixturenotex-20261115.service'
BASELINE = ROOT / 'v5-off-fixturenotex.json'
CANDIDATE = ROOT / 'v6-nativev5-short-fixturenotex.json'
print('Waiting for actual corrected baseline', BASELINE_UNIT, flush=True)
pid = int(subprocess.check_output(['systemctl', '--user', 'show', BASELINE_UNIT,
                                   '-p', 'MainPID', '--value'], text=True).strip() or '0')
if pid:
    try:
        descriptor = os.pidfd_open(pid)
    except ProcessLookupError:
        pass
    else:
        select.select([descriptor], [], [])
        os.close(descriptor)
baseline = json.loads(BASELINE.read_text())
if len(baseline['synth']['results']) != 40:
    raise RuntimeError('refusing candidate without all 40 actual baseline observations')
subprocess.run(['systemctl', '--user', 'stop', 'justrust-hybrid-route-retain-off-20261115.service'], check=False)
manifest = gate.load_verified(MANIFEST)
coverage_dir = ROOT / 'retained-candidate-short-fixturenotex'
sidecar = subprocess.Popen([sys.executable, '-u', str(ROOT / 'retain-canonical-logs.py'),
                            '/home/jeremy/.justrust/bench/versus/logs', str(coverage_dir)],
                           stdout=subprocess.PIPE, text=True)
ready = sidecar.stdout.readline()
if 'route retention ready' not in ready:
    raise RuntimeError('routing retention sidecar did not become ready: ' + ready)
print(ready, end='', flush=True)
command = [sys.executable, '/home/jeremy/justrust/bench/suite.py', 'run', '--synth', '1',
           '-n', '1', '--points', '40', '-o', str(CANDIDATE)]
env = dict(os.environ)
socket_path = Path(env['JR_ENGINE_HOME']) / 'resident-v1/runtime/daemon.sock'
if len(os.fsencode(socket_path)) > 107:
    raise RuntimeError('private native daemon socket exceeds Linux pathname limit')
env['JUSTRUST'] = manifest['adapters']['candidate']['path']
evidence = dict(scope=__doc__, started=time.time(), manifest=str(MANIFEST / 'gate.json'),
                baseline=str(BASELINE), candidate=str(CANDIDATE),
                client_confounds='baseline releasev5 versus candidate releasev6, not isolated hybrid-only attribution',
                policies={key: manifest[key] for key in ('fixture_xdg_home', 'fixture_no_tex',
                                                         'fixture_latex_unicode', 'prewarm_after_success')},
                engine_home=env.get('JR_ENGINE_HOME'), promotion_authorized=False)
try:
    evidence['run'] = gate.invoke(command, env, ROOT / 'v6-nativev5-short-fixturenotex.log')
finally:
    sidecar.send_signal(signal.SIGTERM)
    output = sidecar.communicate(timeout=30)[0]
    print(output, flush=True)
    evidence['sidecar_returncode'] = sidecar.returncode
try:
    gate.load_verified(MANIFEST)
    evidence['inputs_unchanged'] = True
except ValueError as error:
    evidence['inputs_unchanged'] = False
    evidence['input_error'] = str(error)
if CANDIDATE.exists():
    candidate = json.loads(CANDIDATE.read_text())
    evidence['comparison'] = gate.invoke([sys.executable, '/home/jeremy/justrust/bench/suite.py',
                                         'compare', '--require-valid', str(BASELINE), str(CANDIDATE)],
                                        env, ROOT / 'v6-nativev5-short-fixturenotex-compare.log')
    evidence['outcome_parity_issues'] = gate.outcome_parity(baseline, candidate)
    retained = json.loads((coverage_dir / 'summary.json').read_text())
    rows = {row['file']: row for row in retained['retained']}
    coverage = []
    for point in candidate['synth']['results']:
        for sample in point['samples']['suite']:
            name = 'synth-suite-run-' + str(sample.get('id')) + '.log'
            row = rows.get(name)
            coverage.append(dict(point=point['i'], sample_id=sample.get('id'),
                                 retained=row is not None,
                                 committed=row['committed'] if row else None,
                                 fallback=row['fallback'] if row else None))
    evidence['measured_route_coverage'] = coverage
    evidence['routing_retention_complete'] = (not retained['overflow'] and not retained['missed_create_open']
                                              and all(row['retained'] for row in coverage))
    evidence['measured_committed_samples'] = sum(bool(row['committed']) for row in coverage)
    evidence['comparison_eligible'] = (evidence['comparison']['returncode'] == 0
                                       and evidence['inputs_unchanged']
                                       and not evidence['outcome_parity_issues']
                                       and evidence['routing_retention_complete']
                                       and evidence['measured_committed_samples'] > 0)
else:
    evidence['comparison_eligible'] = False
try:
    cleanup = subprocess.run([manifest['tools']['candidate']['path'], 'hybrid', 'stop'], env=dict(env,
                               JUSTRUST_NATIVE_ENGINE=manifest['tools']['engine']['path'],
                               JUSTRUST_HYBRID_TOOLCHAIN=manifest['native_toolchain']), text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
    evidence['namespace_cleanup'] = dict(returncode=cleanup.returncode, output=cleanup.stdout)
except subprocess.TimeoutExpired as error:
    evidence['namespace_cleanup'] = dict(returncode=None, error=str(error))
evidence['finished'] = time.time()
with (ROOT / 'v6-nativev5-short-fixturenotex-evidence.json').open('x') as stream:
    json.dump(evidence, stream, indent=2)
    stream.write('\n')
print(json.dumps(evidence, indent=2), flush=True)
raise SystemExit(0 if evidence['comparison_eligible'] else 2)
