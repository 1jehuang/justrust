#!/usr/bin/env python3
"""Independently verify completed rows interrupted during final integrity checks.
Never changes original metadata, receipts, records, or measurement timings.
"""
import hashlib
import json
from pathlib import Path
import sys
import resident_tier_compare as tier

root = Path(sys.argv[1]).resolve()
metadata = json.loads((root / 'metadata.json').read_text())
rows = json.loads((root / 'records.json').read_text())
receipts = json.loads((root / 'receipts.json').read_text())
checks = {}
source = Path('/home/jeremy/rt15-input/source63')
toolchain = Path('/home/jeremy/rt15-input/nightly-2026-10-27-x86_64-unknown-linux-gnu')
checks['all_60_measurements_accepted'] = len(rows) == 60 and all(r.get('accepted') for r in rows)
checks['pristine_source_unchanged'] = tier.shared.source_hashes(source) == metadata['source_before']
checks['copies_restored'] = all(tier.shared.source_hashes(root / f'm{i}' / name) == metadata['source_before']
    for i in (0, 1) for name in ('a', 'b'))
checks['tools_unchanged'] = all(tier.runtime.base.digest(Path(v['path'])) == v['sha256']
    for v in metadata['tools_before'].values())
checks['toolchain_unchanged'] = tier.shared.toolchain_identity(toolchain) == metadata['toolchain_before']
checks['toolchain_links_valid'] = all(
    (Path(env['BLAZE_HOME']) / 'toolchains' / toolchain.name).is_symlink()
    and (Path(env['BLAZE_HOME']) / 'toolchains' / toolchain.name).resolve() == toolchain
    for env in metadata['environments'].values())
raw = [v for r in receipts for v in r['raw'].values()]
raw += [v for r in rows for v in r.get('native_evidence', {}).get('raw', [])]
raw += [r['transition']['eviction_log'] for r in rows
    if r.get('transition') and 'eviction_log' in r['transition']]
checks['all_raw_hashes_match'] = all(tier.runtime.base.digest(Path(v['path'])) == v['sha256'] for v in raw)
checks['both_final_stop_commands_succeeded'] = all(any(r['label'] == mode + '-final-stop'
    and r['status'] == 0 and not r.get('error') and not r.get('timed_out') for r in receipts)
    for mode in tier.BUDGET_MODES)
# Explicit recorded process identities must be absent, not just a successful stop message.
pids = {p['pid']: p['start_ticks'] for r in rows for key in ('memory_before', 'memory_after')
    for p in r.get(key, []) if p.get('start_ticks') is not None}
checks['recorded_processes_gone'] = all(tier.process_gone(dict(pid=pid, start_ticks=tick))
    for pid, tick in pids.items())
verified = all(checks.values())
states = tier.summarize(rows, metadata['samples'], verified,
    modes=tier.BUDGET_MODES, phases=tier.BUDGET_PHASES)
complete = verified and all(not state['excluded'] for phase in states.values() for state in phase.values())
result = dict(status='independently-verified-complete' if complete else 'failed',
    original_status=metadata['status'],
    recovery_reason='Owning agent server reloaded after all timed rows and both stop commands, before final integrity save.',
    original_metadata_unchanged=True, checks=checks, verified_raw_streams=len(raw),
    original_files_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest()
        for name in ('metadata.json', 'records.json', 'receipts.json')},
    states=states, tiers=metadata['tiers'], policy=metadata['policy'])
path = root / 'independent-verification.json'
with path.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
sys.exit(0 if complete else 1)
