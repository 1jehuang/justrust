#!/usr/bin/env python3
"""Read-only Linux log retention. Raw markers are observations, not benchmark acceptance."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import struct
import sys
import time

source, output = map(Path, sys.argv[1:3])
output.mkdir(mode=0o700, exist_ok=False)
libc = ctypes.CDLL(None, use_errno=True)
fd = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
if fd < 0:
    raise OSError(ctypes.get_errno(), 'inotify_init1')
if libc.inotify_add_watch(fd, os.fsencode(source), 0x100 | 0x4000) < 0:
    raise OSError(ctypes.get_errno(), 'inotify_add_watch')
opened = {}
missed = []
overflow = False
running = True
started = time.time()
def stop(*unused):
    global running
    running = False
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
(output / 'ready.json').write_text(json.dumps(dict(pid=os.getpid(), started=started, source=str(source))) + '\n')
print('route retention ready', os.getpid(), str(output), flush=True)
while running:
    if not select.select([fd], [], [], 0.25)[0]:
        continue
    events = os.read(fd, 65536)
    index = 0
    while index < len(events):
        watch, mask, cookie, length = struct.unpack_from('iIII', events, index)
        index += 16
        name = os.fsdecode(events[index:index + length].split(b'\0', 1)[0])
        index += length
        if mask & 0x4000:
            overflow = True
        if not mask & 0x100 or not name.startswith('synth-suite-') or not name.endswith('.log'):
            continue
        try:
            opened[name] = os.open(source / name, os.O_RDONLY | os.O_CLOEXEC)
        except FileNotFoundError:
            missed.append(name)
rows = []
for name, descriptor in opened.items():
    with os.fdopen(descriptor, 'rb') as stream:
        data = stream.read()
    (output / name).write_bytes(data)
    rows.append(dict(file=name, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                     committed=data.count(b'justrust hybrid: resident committed'),
                     fallback=data.count(b'justrust hybrid: Cargo fallback'),
                     prewarm_finished=data.count(b'justrust hybrid: background prewarm finished status=0')))
os.close(fd)
report = dict(scope=__doc__, started=started, finished=time.time(), source=str(source),
              overflow=overflow, missed_create_open=missed, retained=rows,
              claim='Observed literal client stderr markers only. Match every canonical sample ID and verify no missed files before claiming routing coverage.')
(output / 'summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, sort_keys=True), flush=True)
