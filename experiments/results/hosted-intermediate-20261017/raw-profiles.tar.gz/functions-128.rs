fn f0(x:i32)->i32 { if x < 0 { -x } else { x + 0 } }
fn f1(x:i32)->i32 { if x < 0 { -x } else { x + 1 } }
fn f2(x:i32)->i32 { if x < 0 { -x } else { x + 2 } }
fn f3(x:i32)->i32 { if x < 0 { -x } else { x + 3 } }
fn f4(x:i32)->i32 { if x < 0 { -x } else { x + 4 } }
fn f5(x:i32)->i32 { if x < 0 { -x } else { x + 5 } }
fn f6(x:i32)->i32 { if x < 0 { -x } else { x + 6 } }
fn f7(x:i32)->i32 { if x < 0 { -x } else { x + 7 } }
fn f8(x:i32)->i32 { if x < 0 { -x } else { x + 8 } }
fn f9(x:i32)->i32 { if x < 0 { -x } else { x + 9 } }
fn f10(x:i32)->i32 { if x < 0 { -x } else { x + 10 } }
fn f11(x:i32)->i32 { if x < 0 { -x } else { x + 11 } }
fn f12(x:i32)->i32 { if x < 0 { -x } else { x + 12 } }
fn f13(x:i32)->i32 { if x < 0 { -x } else { x + 13 } }
fn f14(x:i32)->i32 { if x < 0 { -x } else { x + 14 } }
fn f15(x:i32)->i32 { if x < 0 { -x } else { x + 15 } }
fn f16(x:i32)->i32 { if x < 0 { -x } else { x + 16 } }
fn f17(x:i32)->i32 { if x < 0 { -x } else { x + 17 } }
fn f18(x:i32)->i32 { if x < 0 { -x } else { x + 18 } }
fn f19(x:i32)->i32 { if x < 0 { -x } else { x + 19 } }
fn f20(x:i32)->i32 { if x < 0 { -x } else { x + 20 } }
fn f21(x:i32)->i32 { if x < 0 { -x } else { x + 21 } }
fn f22(x:i32)->i32 { if x < 0 { -x } else { x + 22 } }
fn f23(x:i32)->i32 { if x < 0 { -x } else { x + 23 } }
fn f24(x:i32)->i32 { if x < 0 { -x } else { x + 24 } }
fn f25(x:i32)->i32 { if x < 0 { -x } else { x + 25 } }
fn f26(x:i32)->i32 { if x < 0 { -x } else { x + 26 } }
fn f27(x:i32)->i32 { if x < 0 { -x } else { x + 27 } }
fn f28(x:i32)->i32 { if x < 0 { -x } else { x + 28 } }
fn f29(x:i32)->i32 { if x < 0 { -x } else { x + 29 } }
fn f30(x:i32)->i32 { if x < 0 { -x } else { x + 30 } }
fn f31(x:i32)->i32 { if x < 0 { -x } else { x + 31 } }
fn f32(x:i32)->i32 { if x < 0 { -x } else { x + 32 } }
fn f33(x:i32)->i32 { if x < 0 { -x } else { x + 33 } }
fn f34(x:i32)->i32 { if x < 0 { -x } else { x + 34 } }
fn f35(x:i32)->i32 { if x < 0 { -x } else { x + 35 } }
fn f36(x:i32)->i32 { if x < 0 { -x } else { x + 36 } }
fn f37(x:i32)->i32 { if x < 0 { -x } else { x + 37 } }
fn f38(x:i32)->i32 { if x < 0 { -x } else { x + 38 } }
fn f39(x:i32)->i32 { if x < 0 { -x } else { x + 39 } }
fn f40(x:i32)->i32 { if x < 0 { -x } else { x + 40 } }
fn f41(x:i32)->i32 { if x < 0 { -x } else { x + 41 } }
fn f42(x:i32)->i32 { if x < 0 { -x } else { x + 42 } }
fn f43(x:i32)->i32 { if x < 0 { -x } else { x + 43 } }
fn f44(x:i32)->i32 { if x < 0 { -x } else { x + 44 } }
fn f45(x:i32)->i32 { if x < 0 { -x } else { x + 45 } }
fn f46(x:i32)->i32 { if x < 0 { -x } else { x + 46 } }
fn f47(x:i32)->i32 { if x < 0 { -x } else { x + 47 } }
fn f48(x:i32)->i32 { if x < 0 { -x } else { x + 48 } }
fn f49(x:i32)->i32 { if x < 0 { -x } else { x + 49 } }
fn f50(x:i32)->i32 { if x < 0 { -x } else { x + 50 } }
fn f51(x:i32)->i32 { if x < 0 { -x } else { x + 51 } }
fn f52(x:i32)->i32 { if x < 0 { -x } else { x + 52 } }
fn f53(x:i32)->i32 { if x < 0 { -x } else { x + 53 } }
fn f54(x:i32)->i32 { if x < 0 { -x } else { x + 54 } }
fn f55(x:i32)->i32 { if x < 0 { -x } else { x + 55 } }
fn f56(x:i32)->i32 { if x < 0 { -x } else { x + 56 } }
fn f57(x:i32)->i32 { if x < 0 { -x } else { x + 57 } }
fn f58(x:i32)->i32 { if x < 0 { -x } else { x + 58 } }
fn f59(x:i32)->i32 { if x < 0 { -x } else { x + 59 } }
fn f60(x:i32)->i32 { if x < 0 { -x } else { x + 60 } }
fn f61(x:i32)->i32 { if x < 0 { -x } else { x + 61 } }
fn f62(x:i32)->i32 { if x < 0 { -x } else { x + 62 } }
fn f63(x:i32)->i32 { if x < 0 { -x } else { x + 63 } }
fn f64(x:i32)->i32 { if x < 0 { -x } else { x + 64 } }
fn f65(x:i32)->i32 { if x < 0 { -x } else { x + 65 } }
fn f66(x:i32)->i32 { if x < 0 { -x } else { x + 66 } }
fn f67(x:i32)->i32 { if x < 0 { -x } else { x + 67 } }
fn f68(x:i32)->i32 { if x < 0 { -x } else { x + 68 } }
fn f69(x:i32)->i32 { if x < 0 { -x } else { x + 69 } }
fn f70(x:i32)->i32 { if x < 0 { -x } else { x + 70 } }
fn f71(x:i32)->i32 { if x < 0 { -x } else { x + 71 } }
fn f72(x:i32)->i32 { if x < 0 { -x } else { x + 72 } }
fn f73(x:i32)->i32 { if x < 0 { -x } else { x + 73 } }
fn f74(x:i32)->i32 { if x < 0 { -x } else { x + 74 } }
fn f75(x:i32)->i32 { if x < 0 { -x } else { x + 75 } }
fn f76(x:i32)->i32 { if x < 0 { -x } else { x + 76 } }
fn f77(x:i32)->i32 { if x < 0 { -x } else { x + 77 } }
fn f78(x:i32)->i32 { if x < 0 { -x } else { x + 78 } }
fn f79(x:i32)->i32 { if x < 0 { -x } else { x + 79 } }
fn f80(x:i32)->i32 { if x < 0 { -x } else { x + 80 } }
fn f81(x:i32)->i32 { if x < 0 { -x } else { x + 81 } }
fn f82(x:i32)->i32 { if x < 0 { -x } else { x + 82 } }
fn f83(x:i32)->i32 { if x < 0 { -x } else { x + 83 } }
fn f84(x:i32)->i32 { if x < 0 { -x } else { x + 84 } }
fn f85(x:i32)->i32 { if x < 0 { -x } else { x + 85 } }
fn f86(x:i32)->i32 { if x < 0 { -x } else { x + 86 } }
fn f87(x:i32)->i32 { if x < 0 { -x } else { x + 87 } }
fn f88(x:i32)->i32 { if x < 0 { -x } else { x + 88 } }
fn f89(x:i32)->i32 { if x < 0 { -x } else { x + 89 } }
fn f90(x:i32)->i32 { if x < 0 { -x } else { x + 90 } }
fn f91(x:i32)->i32 { if x < 0 { -x } else { x + 91 } }
fn f92(x:i32)->i32 { if x < 0 { -x } else { x + 92 } }
fn f93(x:i32)->i32 { if x < 0 { -x } else { x + 93 } }
fn f94(x:i32)->i32 { if x < 0 { -x } else { x + 94 } }
fn f95(x:i32)->i32 { if x < 0 { -x } else { x + 95 } }
fn f96(x:i32)->i32 { if x < 0 { -x } else { x + 96 } }
fn f97(x:i32)->i32 { if x < 0 { -x } else { x + 97 } }
fn f98(x:i32)->i32 { if x < 0 { -x } else { x + 98 } }
fn f99(x:i32)->i32 { if x < 0 { -x } else { x + 99 } }
fn f100(x:i32)->i32 { if x < 0 { -x } else { x + 100 } }
fn f101(x:i32)->i32 { if x < 0 { -x } else { x + 101 } }
fn f102(x:i32)->i32 { if x < 0 { -x } else { x + 102 } }
fn f103(x:i32)->i32 { if x < 0 { -x } else { x + 103 } }
fn f104(x:i32)->i32 { if x < 0 { -x } else { x + 104 } }
fn f105(x:i32)->i32 { if x < 0 { -x } else { x + 105 } }
fn f106(x:i32)->i32 { if x < 0 { -x } else { x + 106 } }
fn f107(x:i32)->i32 { if x < 0 { -x } else { x + 107 } }
fn f108(x:i32)->i32 { if x < 0 { -x } else { x + 108 } }
fn f109(x:i32)->i32 { if x < 0 { -x } else { x + 109 } }
fn f110(x:i32)->i32 { if x < 0 { -x } else { x + 110 } }
fn f111(x:i32)->i32 { if x < 0 { -x } else { x + 111 } }
fn f112(x:i32)->i32 { if x < 0 { -x } else { x + 112 } }
fn f113(x:i32)->i32 { if x < 0 { -x } else { x + 113 } }
fn f114(x:i32)->i32 { if x < 0 { -x } else { x + 114 } }
fn f115(x:i32)->i32 { if x < 0 { -x } else { x + 115 } }
fn f116(x:i32)->i32 { if x < 0 { -x } else { x + 116 } }
fn f117(x:i32)->i32 { if x < 0 { -x } else { x + 117 } }
fn f118(x:i32)->i32 { if x < 0 { -x } else { x + 118 } }
fn f119(x:i32)->i32 { if x < 0 { -x } else { x + 119 } }
fn f120(x:i32)->i32 { if x < 0 { -x } else { x + 120 } }
fn f121(x:i32)->i32 { if x < 0 { -x } else { x + 121 } }
fn f122(x:i32)->i32 { if x < 0 { -x } else { x + 122 } }
fn f123(x:i32)->i32 { if x < 0 { -x } else { x + 123 } }
fn f124(x:i32)->i32 { if x < 0 { -x } else { x + 124 } }
fn f125(x:i32)->i32 { if x < 0 { -x } else { x + 125 } }
fn f126(x:i32)->i32 { if x < 0 { -x } else { x + 126 } }
fn f127(x:i32)->i32 { if x < 0 { -x } else { x + 127 } }
fn fail(x:i32) { let y=1/x; }
fn main(){if f0(2) != 2 { fail(0); }
if f1(2) != 3 { fail(0); }
if f2(2) != 4 { fail(0); }
if f3(2) != 5 { fail(0); }
if f4(2) != 6 { fail(0); }
if f5(2) != 7 { fail(0); }
if f6(2) != 8 { fail(0); }
if f7(2) != 9 { fail(0); }
if f8(2) != 10 { fail(0); }
if f9(2) != 11 { fail(0); }
if f10(2) != 12 { fail(0); }
if f11(2) != 13 { fail(0); }
if f12(2) != 14 { fail(0); }
if f13(2) != 15 { fail(0); }
if f14(2) != 16 { fail(0); }
if f15(2) != 17 { fail(0); }
if f16(2) != 18 { fail(0); }
if f17(2) != 19 { fail(0); }
if f18(2) != 20 { fail(0); }
if f19(2) != 21 { fail(0); }
if f20(2) != 22 { fail(0); }
if f21(2) != 23 { fail(0); }
if f22(2) != 24 { fail(0); }
if f23(2) != 25 { fail(0); }
if f24(2) != 26 { fail(0); }
if f25(2) != 27 { fail(0); }
if f26(2) != 28 { fail(0); }
if f27(2) != 29 { fail(0); }
if f28(2) != 30 { fail(0); }
if f29(2) != 31 { fail(0); }
if f30(2) != 32 { fail(0); }
if f31(2) != 33 { fail(0); }
if f32(2) != 34 { fail(0); }
if f33(2) != 35 { fail(0); }
if f34(2) != 36 { fail(0); }
if f35(2) != 37 { fail(0); }
if f36(2) != 38 { fail(0); }
if f37(2) != 39 { fail(0); }
if f38(2) != 40 { fail(0); }
if f39(2) != 41 { fail(0); }
if f40(2) != 42 { fail(0); }
if f41(2) != 43 { fail(0); }
if f42(2) != 44 { fail(0); }
if f43(2) != 45 { fail(0); }
if f44(2) != 46 { fail(0); }
if f45(2) != 47 { fail(0); }
if f46(2) != 48 { fail(0); }
if f47(2) != 49 { fail(0); }
if f48(2) != 50 { fail(0); }
if f49(2) != 51 { fail(0); }
if f50(2) != 52 { fail(0); }
if f51(2) != 53 { fail(0); }
if f52(2) != 54 { fail(0); }
if f53(2) != 55 { fail(0); }
if f54(2) != 56 { fail(0); }
if f55(2) != 57 { fail(0); }
if f56(2) != 58 { fail(0); }
if f57(2) != 59 { fail(0); }
if f58(2) != 60 { fail(0); }
if f59(2) != 61 { fail(0); }
if f60(2) != 62 { fail(0); }
if f61(2) != 63 { fail(0); }
if f62(2) != 64 { fail(0); }
if f63(2) != 65 { fail(0); }
if f64(2) != 66 { fail(0); }
if f65(2) != 67 { fail(0); }
if f66(2) != 68 { fail(0); }
if f67(2) != 69 { fail(0); }
if f68(2) != 70 { fail(0); }
if f69(2) != 71 { fail(0); }
if f70(2) != 72 { fail(0); }
if f71(2) != 73 { fail(0); }
if f72(2) != 74 { fail(0); }
if f73(2) != 75 { fail(0); }
if f74(2) != 76 { fail(0); }
if f75(2) != 77 { fail(0); }
if f76(2) != 78 { fail(0); }
if f77(2) != 79 { fail(0); }
if f78(2) != 80 { fail(0); }
if f79(2) != 81 { fail(0); }
if f80(2) != 82 { fail(0); }
if f81(2) != 83 { fail(0); }
if f82(2) != 84 { fail(0); }
if f83(2) != 85 { fail(0); }
if f84(2) != 86 { fail(0); }
if f85(2) != 87 { fail(0); }
if f86(2) != 88 { fail(0); }
if f87(2) != 89 { fail(0); }
if f88(2) != 90 { fail(0); }
if f89(2) != 91 { fail(0); }
if f90(2) != 92 { fail(0); }
if f91(2) != 93 { fail(0); }
if f92(2) != 94 { fail(0); }
if f93(2) != 95 { fail(0); }
if f94(2) != 96 { fail(0); }
if f95(2) != 97 { fail(0); }
if f96(2) != 98 { fail(0); }
if f97(2) != 99 { fail(0); }
if f98(2) != 100 { fail(0); }
if f99(2) != 101 { fail(0); }
if f100(2) != 102 { fail(0); }
if f101(2) != 103 { fail(0); }
if f102(2) != 104 { fail(0); }
if f103(2) != 105 { fail(0); }
if f104(2) != 106 { fail(0); }
if f105(2) != 107 { fail(0); }
if f106(2) != 108 { fail(0); }
if f107(2) != 109 { fail(0); }
if f108(2) != 110 { fail(0); }
if f109(2) != 111 { fail(0); }
if f110(2) != 112 { fail(0); }
if f111(2) != 113 { fail(0); }
if f112(2) != 114 { fail(0); }
if f113(2) != 115 { fail(0); }
if f114(2) != 116 { fail(0); }
if f115(2) != 117 { fail(0); }
if f116(2) != 118 { fail(0); }
if f117(2) != 119 { fail(0); }
if f118(2) != 120 { fail(0); }
if f119(2) != 121 { fail(0); }
if f120(2) != 122 { fail(0); }
if f121(2) != 123 { fail(0); }
if f122(2) != 124 { fail(0); }
if f123(2) != 125 { fail(0); }
if f124(2) != 126 { fail(0); }
if f125(2) != 127 { fail(0); }
if f126(2) != 128 { fail(0); }
if f127(2) != 129 { fail(0); }println!("compiled correctly");}