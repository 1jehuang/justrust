fn f0(x:i32)->i32 { if x < 0 { -x } else { x + 0 } }
fn f1(x:i32)->i32 { if x < 0 { -x } else { x + 1 } }
fn f2(x:i32)->i32 { if x < 0 { -x } else { x + 2 } }
fn f3(x:i32)->i32 { if x < 0 { -x } else { x + 3 } }
fn f4(x:i32)->i32 { if x < 0 { -x } else { x + 4 } }
fn f5(x:i32)->i32 { if x < 0 { -x } else { x + 5 } }
fn f6(x:i32)->i32 { if x < 0 { -x } else { x + 6 } }
fn f7(x:i32)->i32 { if x < 0 { -x } else { x + 7 } }
fn f8(x:i32)->i32 { if x < 0 { -x } else { x + 8 } }
fn f9(x:i32)->i32 { if x < 0 { -x } else { x + 9 } }
fn f10(x:i32)->i32 { if x < 0 { -x } else { x + 10 } }
fn f11(x:i32)->i32 { if x < 0 { -x } else { x + 11 } }
fn f12(x:i32)->i32 { if x < 0 { -x } else { x + 12 } }
fn f13(x:i32)->i32 { if x < 0 { -x } else { x + 13 } }
fn f14(x:i32)->i32 { if x < 0 { -x } else { x + 14 } }
fn f15(x:i32)->i32 { if x < 0 { -x } else { x + 15 } }
fn f16(x:i32)->i32 { if x < 0 { -x } else { x + 16 } }
fn f17(x:i32)->i32 { if x < 0 { -x } else { x + 17 } }
fn f18(x:i32)->i32 { if x < 0 { -x } else { x + 18 } }
fn f19(x:i32)->i32 { if x < 0 { -x } else { x + 19 } }
fn f20(x:i32)->i32 { if x < 0 { -x } else { x + 20 } }
fn f21(x:i32)->i32 { if x < 0 { -x } else { x + 21 } }
fn f22(x:i32)->i32 { if x < 0 { -x } else { x + 22 } }
fn f23(x:i32)->i32 { if x < 0 { -x } else { x + 23 } }
fn f24(x:i32)->i32 { if x < 0 { -x } else { x + 24 } }
fn f25(x:i32)->i32 { if x < 0 { -x } else { x + 25 } }
fn f26(x:i32)->i32 { if x < 0 { -x } else { x + 26 } }
fn f27(x:i32)->i32 { if x < 0 { -x } else { x + 27 } }
fn f28(x:i32)->i32 { if x < 0 { -x } else { x + 28 } }
fn f29(x:i32)->i32 { if x < 0 { -x } else { x + 29 } }
fn f30(x:i32)->i32 { if x < 0 { -x } else { x + 30 } }
fn f31(x:i32)->i32 { if x < 0 { -x } else { x + 31 } }
fn f32(x:i32)->i32 { if x < 0 { -x } else { x + 32 } }
fn f33(x:i32)->i32 { if x < 0 { -x } else { x + 33 } }
fn f34(x:i32)->i32 { if x < 0 { -x } else { x + 34 } }
fn f35(x:i32)->i32 { if x < 0 { -x } else { x + 35 } }
fn f36(x:i32)->i32 { if x < 0 { -x } else { x + 36 } }
fn f37(x:i32)->i32 { if x < 0 { -x } else { x + 37 } }
fn f38(x:i32)->i32 { if x < 0 { -x } else { x + 38 } }
fn f39(x:i32)->i32 { if x < 0 { -x } else { x + 39 } }
fn f40(x:i32)->i32 { if x < 0 { -x } else { x + 40 } }
fn f41(x:i32)->i32 { if x < 0 { -x } else { x + 41 } }
fn f42(x:i32)->i32 { if x < 0 { -x } else { x + 42 } }
fn f43(x:i32)->i32 { if x < 0 { -x } else { x + 43 } }
fn f44(x:i32)->i32 { if x < 0 { -x } else { x + 44 } }
fn f45(x:i32)->i32 { if x < 0 { -x } else { x + 45 } }
fn f46(x:i32)->i32 { if x < 0 { -x } else { x + 46 } }
fn f47(x:i32)->i32 { if x < 0 { -x } else { x + 47 } }
fn f48(x:i32)->i32 { if x < 0 { -x } else { x + 48 } }
fn f49(x:i32)->i32 { if x < 0 { -x } else { x + 49 } }
fn f50(x:i32)->i32 { if x < 0 { -x } else { x + 50 } }
fn f51(x:i32)->i32 { if x < 0 { -x } else { x + 51 } }
fn f52(x:i32)->i32 { if x < 0 { -x } else { x + 52 } }
fn f53(x:i32)->i32 { if x < 0 { -x } else { x + 53 } }
fn f54(x:i32)->i32 { if x < 0 { -x } else { x + 54 } }
fn f55(x:i32)->i32 { if x < 0 { -x } else { x + 55 } }
fn f56(x:i32)->i32 { if x < 0 { -x } else { x + 56 } }
fn f57(x:i32)->i32 { if x < 0 { -x } else { x + 57 } }
fn f58(x:i32)->i32 { if x < 0 { -x } else { x + 58 } }
fn f59(x:i32)->i32 { if x < 0 { -x } else { x + 59 } }
fn f60(x:i32)->i32 { if x < 0 { -x } else { x + 60 } }
fn f61(x:i32)->i32 { if x < 0 { -x } else { x + 61 } }
fn f62(x:i32)->i32 { if x < 0 { -x } else { x + 62 } }
fn f63(x:i32)->i32 { if x < 0 { -x } else { x + 63 } }
fn fail(x:i32) { let y=1/x; }
fn main(){if f0(2) != 2 { fail(0); }
if f1(2) != 3 { fail(0); }
if f2(2) != 4 { fail(0); }
if f3(2) != 5 { fail(0); }
if f4(2) != 6 { fail(0); }
if f5(2) != 7 { fail(0); }
if f6(2) != 8 { fail(0); }
if f7(2) != 9 { fail(0); }
if f8(2) != 10 { fail(0); }
if f9(2) != 11 { fail(0); }
if f10(2) != 12 { fail(0); }
if f11(2) != 13 { fail(0); }
if f12(2) != 14 { fail(0); }
if f13(2) != 15 { fail(0); }
if f14(2) != 16 { fail(0); }
if f15(2) != 17 { fail(0); }
if f16(2) != 18 { fail(0); }
if f17(2) != 19 { fail(0); }
if f18(2) != 20 { fail(0); }
if f19(2) != 21 { fail(0); }
if f20(2) != 22 { fail(0); }
if f21(2) != 23 { fail(0); }
if f22(2) != 24 { fail(0); }
if f23(2) != 25 { fail(0); }
if f24(2) != 26 { fail(0); }
if f25(2) != 27 { fail(0); }
if f26(2) != 28 { fail(0); }
if f27(2) != 29 { fail(0); }
if f28(2) != 30 { fail(0); }
if f29(2) != 31 { fail(0); }
if f30(2) != 32 { fail(0); }
if f31(2) != 33 { fail(0); }
if f32(2) != 34 { fail(0); }
if f33(2) != 35 { fail(0); }
if f34(2) != 36 { fail(0); }
if f35(2) != 37 { fail(0); }
if f36(2) != 38 { fail(0); }
if f37(2) != 39 { fail(0); }
if f38(2) != 40 { fail(0); }
if f39(2) != 41 { fail(0); }
if f40(2) != 42 { fail(0); }
if f41(2) != 43 { fail(0); }
if f42(2) != 44 { fail(0); }
if f43(2) != 45 { fail(0); }
if f44(2) != 46 { fail(0); }
if f45(2) != 47 { fail(0); }
if f46(2) != 48 { fail(0); }
if f47(2) != 49 { fail(0); }
if f48(2) != 50 { fail(0); }
if f49(2) != 51 { fail(0); }
if f50(2) != 52 { fail(0); }
if f51(2) != 53 { fail(0); }
if f52(2) != 54 { fail(0); }
if f53(2) != 55 { fail(0); }
if f54(2) != 56 { fail(0); }
if f55(2) != 57 { fail(0); }
if f56(2) != 58 { fail(0); }
if f57(2) != 59 { fail(0); }
if f58(2) != 60 { fail(0); }
if f59(2) != 61 { fail(0); }
if f60(2) != 62 { fail(0); }
if f61(2) != 63 { fail(0); }
if f62(2) != 64 { fail(0); }
if f63(2) != 65 { fail(0); }println!("compiled correctly");}